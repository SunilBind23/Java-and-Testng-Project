package new_package;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;

public class And_generic {

	static WebDriver driver;
	public  static void  browser(String browserName) {


		switch(browserName) {

		case "chrome":
			driver= new ChromeDriver();
			System.out.println(browserName+" has lanunched Succesfully ");

			break;
		case "firefox":
			driver=   new FirefoxDriver();
			System.out.println(browserName+" has lanunched Succesfully ");


		default :
			System.out.println("wrong browser name ");

		}


	}

	public static void hitURL(String url) {
		driver.get(url);
		System.out.println(url+" hit on  the wwb page Succesfully");

	}
	public  static WebElement getElement(String xpath,String ElementName) throws InterruptedException {
		WebElement   element=null; 
		try {  
			element=     driver.findElement(By.xpath(xpath));///
			System.out.println(ElementName+" has found Succesfully");    

		}  
		catch(NoSuchElementException e) {
			Thread.sleep(2000);
			element=     driver.findElement(By.xpath(xpath));          
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}

  return element;

		

	}
	public static void  enterdata (String xpath,String enterValue, String ElementName) throws InterruptedException {
		WebElement element=   getElement(xpath,ElementName);
		element.clear();
		element.sendKeys(enterValue);
		System.out.println("this data "+enterValue+" has entered Succesfully on the  "+ElementName);



	}


	public static void click(String xpath ,String elementName) throws InterruptedException {
		WebElement element=  getElement(xpath,elementName); 
		element.click();
		System.out.println( " this "+elementName+"  has clicked  Succesfully ");


	}





}
