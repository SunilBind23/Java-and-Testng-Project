package new_package;



import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class TestRunner {

	public static void main(String[] args) throws InterruptedException {

		// Extent report jar spark extent reporter
		ExtentReports extReport=new ExtentReports();
		ExtentSparkReporter extSpark=new ExtentSparkReporter("C:\\Users\\DELL\\Desktop\\extent_report.html");
		extReport.attachReporter(extSpark);
		ExtentTest et= extReport.createTest("vt001");
		myGenericMethod.setExtentest(et);
		
		TestScript ts=new TestScript();
		ts.vt001VerifyLeadsTestScript();

		extReport.flush();

	}

}
