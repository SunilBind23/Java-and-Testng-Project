package new_package;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestScript {

public void vt001VerifyLeadsTestScript() {
	
	myGenericMethod gm=new myGenericMethod();
	gm.launchBrowser("chrome", 20);
	gm.openURL("http://localhost:8888");
	
	WebElement uName= gm.getWebElement(By.xpath("//input[@name='user_name']"), "User name");
	gm.type(uName, "admin", "User name");
	
	WebElement uPass= gm.getWebElement(By.xpath("//input[@name='user_password']"), "User napasswordme");
	gm.type(uPass, "admin", "User password");
	
	WebElement cl =gm.getWebElement(By.xpath("//input[@id='submitButton']"), "clickBt");
    gm.click(cl, "clickbbt");
}
	
}









	






