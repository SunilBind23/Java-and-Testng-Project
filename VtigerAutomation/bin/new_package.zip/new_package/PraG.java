package new_package;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Set;

import javax.lang.model.element.Element;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.InvalidSelectorException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.support.ui.Select;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.google.common.io.Files;

import io.reactivex.rxjava3.functions.Action;

public class PraG {
	public WebDriver driver;
	private static ExtentTest et;
	public WebElement we;
	public String str;

	public static void extentTestR(ExtentTest etttt) {

		et = etttt;

	}

	//	public  ExtentTest report() {
	//		er=new ExtentReports();
	//		ExtentSparkReporter esr = new ExtentSparkReporter("C:\\Users\\DELL\\Desktop\\report.html");
	//		er.attachReporter(esr);
	//		ExtentTest  et =er.createTest("vv01");
	//		return et;
	//
	//	}

	public void browserlaunch(String browsername) {

		switch (browsername) {
		case "chrome":
			driver = new ChromeDriver();
			System.out.println(browsername + " has lanunched Succesfully ");
			et.log(Status.INFO, browsername + " has launched successfully");
			break;
		case "edge":
			driver = new EdgeDriver();
			System.out.println(browsername + " has lanunched Succesfully ");
			break;
		case "safari":
			driver = new SafariDriver();
			System.out.println(browsername + " has lanunched Succesfully ");

			break;
		case "firefox":
			driver = new FirefoxDriver();
			System.out.println(browsername + " has lanunched Succesfully ");

			break;

		default:
			System.out.println("wrong browser name");
		}
	}

	public void getURL(String url, String browserName) {
		browserlaunch(browserName);
		driver.get(url);

		et.log(Status.INFO, "url is open");

	}

	public WebElement getElement(String xpath, String Elementname) {

		try {
			we = driver.findElement(By.xpath(xpath));
			et.log(Status.INFO, Elementname + " has found Succesfully");
		} catch (NoSuchElementException e) {
			we = driver.findElement(By.xpath(xpath));
			et.log(Status.INFO, Elementname + " has found Succesfully");
		} catch (ElementNotInteractableException e) {
			we = driver.findElement(By.xpath(xpath));
			et.log(Status.INFO, Elementname + " has found Succesfully");
		} catch (InvalidSelectorException e) {
			we = driver.findElement(By.xpath(xpath));
			et.log(Status.INFO, Elementname + " has found Succesfully");
		} catch (Exception e) {
			we = driver.findElement(By.xpath(xpath));
			et.log(Status.INFO, Elementname + " has found Succesfully");
		}
		return we;

	}

	public void sendtype(String xpath, String value, String Elementname) {
		try {
			we = getElement(xpath, Elementname);
			we.sendKeys(value);
			et.log(Status.INFO, "this data " + value + "has entered successfully on the " + Elementname);
		} catch (NoSuchElementException e) {
			et.log(Status.INFO, "this data " + value + "has entered successfully on the " + Elementname);
		} catch (InvalidSelectorException e) {
			et.log(Status.INFO, "this data " + value + "has entered successfully on the " + Elementname);
		} catch (Exception e) {
			et.log(Status.INFO, "this data " + value + "has entered successfully on the " + Elementname);
		}

	}

	public void click(String xpath, String Elementname) {
		try {
			we = getElement(xpath, Elementname);
			we.click();
			et.log(Status.INFO, "this" + Elementname + " has clicked successfully");

		} catch (ElementClickInterceptedException e) {
			we = getElement(xpath, Elementname);

			we.click();
			et.log(Status.INFO, "this" + Elementname + " has clicked successfully");

		} catch (StaleElementReferenceException e) {
			we.click();
			et.log(Status.INFO, "this" + Elementname + " has clicked successfully");

		}
	}

	public void CloseBrowser() {
		try {
			driver.close();
			et.log(Status.INFO, "Browser is closed successfully");

		} catch (Exception e) {
			et.log(Status.INFO, "Browser is closed successfully" + e.getMessage());
		}

	}

	public void CloseAllbrowser() {
		try {
			driver.quit();
			et.log(Status.INFO, "AllBrowser is closed successfully");
		} catch (Exception e) {
			et.log(Status.INFO, "AllBrowser is closed successfully" + e.getMessage());
		}

	}

	public void selectbyVisible(String xpath, String innertext) {

		Select stc = new Select(getElement(xpath, innertext));
		stc.selectByVisibleText(innertext);
	}

	public void selectbyIndex(String xpath, String ElemenetName, int index) {
		Select stc = new Select(getElement(xpath, ElemenetName));
		stc.selectByIndex(index);
	}

	public void selectbyValue(String xpath, String ElemenetName, String value) {
		Select stc = new Select(getElement(xpath, ElemenetName));
		stc.selectByValue(value);

	}

	public void mouseover(String xpath, String Elementname) {
		we = getElement(xpath, Elementname);
		Actions act = new Actions(driver);
		act.moveToElement(we).build().perform();
		;

	}

	public void Actionrightclick(WebElement we, String xpath, String Elementname) {
		try {
			we = getElement(xpath, Elementname);
			Actions acto = new Actions(driver);
			acto.contextClick(we).build().perform();

		}catch(ElementClickInterceptedException e) {
			et.log(Status.INFO, "this" + Elementname + " has clicked successfully");

		}
	}
	public void Actiondoubleclick(WebElement we, String xpath, String Elementname) {
		try {
			we = getElement(xpath, Elementname);
			Actions acto = new Actions(driver);
			acto.doubleClick().build().perform();
		}catch(ElementClickInterceptedException e) {
			et.log(Status.INFO, "this" + Elementname + " has clicked successfully");
		}catch(Exception e) {
			et.log(Status.INFO, "this" + Elementname + " has clicked successfully");
		}

	}

	public void actioncontextclick(WebElement we, String xpath, String Elementname) {
		try {
			we = getElement(xpath, Elementname);
			Actions act = new Actions(driver);
			act.contextClick();
		}catch (ElementClickInterceptedException e){
			et.log(Status.INFO, "this" + Elementname + " has clicked successfully");
		}
	}


	public void scroll(String xpath, String Elementname) {
		try {
		we = getElement(xpath, Elementname);
		Actions action = new Actions(driver);
		action.scrollToElement(we).build().perform();
		} catch (Exception e) {
			et.log(Status.INFO, "Exception is - "+e.getMessage());
		}

	}

	public void scrolByamount(int index1, int index2, String Elementname) {
		// wb = getElement(xpath,Elementname);
		Actions action = new Actions(driver);
		action.scrollByAmount(index1, index2).build().perform();
	}

	public void Actiondraganddrop(WebElement we, String xpath1, String xapth2, String Elementname) {
		Actions actobj = new Actions(driver);
		we = getElement(xpath1, Elementname);
		WebElement we1 = getElement(xapth2, Elementname);
		actobj.dragAndDrop(we, we1).build().perform();

	}

	public void GetText(String xpath, String Elementname) {
		we = getElement(xpath, Elementname);
		String str = we.getText();
		System.out.println("inner  Text " + str);
	}

	public void isDisplay(String xpath, String Elementname) {
		we = getElement(xpath, Elementname);
		boolean bt = we.isDisplayed();
		if (bt == true) {
			et.log(Status.INFO, Elementname + " is displayed ");
		} else {
			et.log(Status.FAIL, Elementname + " is not displayed");
		}

	}

	public void isSelected(String xpath, String Elementname) {
		we = getElement(xpath, Elementname);
		boolean tb = we.isSelected();
		if (tb == true) {
			et.log(Status.INFO, Elementname + " is selected ");
		} else {
			et.log(Status.FAIL, Elementname + " is unselected ");
		}

	}

	public void isEnable(String xpath, String Elementname) {
		we = getElement(xpath, Elementname);
		boolean bt = we.isEnabled();
		if (bt == true) {
			et.log(Status.INFO, Elementname + " is enable ");
		} else {
			et.log(Status.FAIL, Elementname + " is disable ");

		}
	}

	//////////////////////////////////////////////////////////////////////////////////////////////////////
	public void SwitchWindowByTitle(String Elementname) {
		Set<String> windows = driver.getWindowHandles();
		for (String handle : windows) {
			driver.switchTo().window(handle);
			String actualtitle = driver.getTitle();
			if (actualtitle.equalsIgnoreCase(actualtitle)) {
				break;
			}
		}

	}

	public void GetAttribute(WebElement we, String xpath, String Elementname, String Attributename) {
		we = getElement(xpath, Elementname);
		String str = we.getAttribute(Attributename);
		System.out.println(str);
	}

	public void ActionSendKey(WebElement we, String xpath, String Elementname, String value) {
		we = getElement(xpath, Elementname);
		Actions actobj = new Actions(driver);
		actobj.sendKeys(value);

	}

	public void GetFirstSelectOption(WebElement we, String xpath, String Elementname) {
		we = getElement(xpath, Elementname);
		Select sct = new Select(we);
		WebElement west = sct.getFirstSelectedOption();
		System.out.println(west);
	}

	public void GetAllSelectedOption(WebElement we, String xpath, String Elementname) {
		we = getElement(xpath, Elementname);
		Select sct = new Select(we);
		List<WebElement> welist = sct.getAllSelectedOptions();
		System.out.println(welist);
	}

	public Actions ActionObject(WebDriver driver) {
		Actions actobj = new Actions(driver);
		return actobj;

	}

	public void AleartAccept(WebElement we, String xpath, String Elementname) {
		we = getElement(xpath, Elementname);
		we.click();
		Alert alrt = driver.switchTo().alert();
		alrt.accept();

	}

	public void AleartDismiss(WebElement we, String xpath, String Elementname) {
		we = getElement(xpath, Elementname);
		we.click();
		Alert alrt = driver.switchTo().alert();
		alrt.dismiss();

	}

	public void SwitchToFrame(WebElement frameElement, String framename) {
		driver.switchTo().frame(frameElement);

	}

	public void SwitchToFrame(int i, String framename) {
		driver.switchTo().frame(i);

	}

	public void SwitchToFrame(String IdOrName, String framename) {
		driver.switchTo().frame(IdOrName);

	}

	public void SwitchToFrame(String mainFrame) {
		driver.switchTo().defaultContent();

	}

	public void TakeScreenShot() throws IOException {
		TakesScreenshot tcs = (TakesScreenshot) driver;
		File file = tcs.getScreenshotAs(OutputType.FILE);
		File dst = new File("C:\\Users\\DELL\\Desktop\\photo.png");
		Files.copy(file, dst);
	}

}
